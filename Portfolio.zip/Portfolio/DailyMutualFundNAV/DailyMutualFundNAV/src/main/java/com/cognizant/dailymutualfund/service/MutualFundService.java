package com.cognizant.dailymutualfund.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.dailymutualfund.controller.AuthClient;
import com.cognizant.dailymutualfund.exception.MutualFundNotFoundException;
import com.cognizant.dailymutualfund.model.AuthResponse;
import com.cognizant.dailymutualfund.model.MutualFund;
import com.cognizant.dailymutualfund.repository.MutualFundRepository;

@Service
public class MutualFundService {
	
	
	@Autowired
	private MutualFundRepository repository;
	
	@Autowired
	private AuthClient authClient;
	
	
	@Transactional
	public List<MutualFund> getAllMutualFund(){
		return repository.findAll();
	}
	
	@Transactional
	public MutualFund getMutualFundByName(String mutualFundName) throws MutualFundNotFoundException{
		if(repository.findByMutualFundName(mutualFundName)==null)
			throw new MutualFundNotFoundException("Mutual Fund Not Found");
		return repository.findByMutualFundName(mutualFundName);
	}

//	public List<Double> getMutualFundById(List<String> mutualFundIdList) {
//		// TODO Auto-generated method stub
//		for(String s:mutualFundIdList) {
//			valueList.add(repository.findByMutualFundId(s).getMutualFundValue());
//		}
//		 return valueList;
//	}
	public List<Double> getMutualFundByIdList(List<String> mutualFundIdList) {
		List<Double> mfValueList = new ArrayList<>();
		List<MutualFund> mfList=  repository.findByMutualFundId(mutualFundIdList);
		for(MutualFund m:mfList) {
			mfValueList.add( m.getMutualFundValue());
		}
		return mfValueList;
	}
	
	public Boolean isSessionValid(String token) {
		try {
			@SuppressWarnings("unused")
			AuthResponse authResponse = authClient.getValidity(token);
		} catch (Exception e) {
			return false;
		} 
		return true;
	}
		

}
