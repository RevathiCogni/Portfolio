INSERT INTO userdata (user_id,user_password,user_name) VALUES ('101','pwd','101');
INSERT INTO userdata (user_id,user_password,user_name) VALUES ('102','admin1','102');
